import { Cliente } from "./Cliente";

export class Carro {
  carroid: number = 0;
  modelo: string = '';
  cor: string = '';

  clienteid: number = 0;
  cliente?: Cliente;
}
