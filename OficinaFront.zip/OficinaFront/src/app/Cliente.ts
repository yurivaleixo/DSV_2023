export class Cliente {
  clienteid: number = 0;
  nome: string = '';
  cpf: string = '';
  email: string = '';
}
